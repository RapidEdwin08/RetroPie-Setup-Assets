#!/bin/bash

# Wait for qemu-arm to start to show PORT(s) in use for $minecraftLOGO
sleep 5

#=======================================
minecraftLOGO=$(
echo "$(hostname -I | tr -d ' ') / `curl -4 icanhazip.com 2>/dev/null | awk '{print $NF; exit}'`
$(lsof -i -P -n | grep qemu-arm | awk '{print $8, $9}')

 [/home/pi/.minecraft-pi/server.properties]:
$(cat /home/pi/.minecraft-pi/server.properties  | grep = | grep -v \#)

Press [QUIT] to KILL SERVER and EXIT... "
)
#=======================================

echo "$minecraftLOGO" >> /dev/shm/runcommand.log

# GUI with JoyPad Support For Dedicated Server from ES - Displays Dedicated Server Dialog - Kills minecraft-pi when [QUIT] is pressed
dialog --no-collapse --ok-label QUIT --title "minecraft-pi is Running as a Dedicated Server:" --msgbox "$minecraftLOGO"  25 75 </dev/tty > /dev/tty

# Run RetroPie [runcommand-onend.sh] after Quit
bash /opt/retropie/configs/all/runcommand-onend.sh > /dev/null 2>&1

# kill instances of minecraft-pi
PIDrunncommandSH=$(ps -eaf | grep "minecraft-pi" | awk '{print $2}')
kill $PIDrunncommandSH > /dev/null 2>&1

pkill qemu-arm # qemu-arm may linger in Server mode
