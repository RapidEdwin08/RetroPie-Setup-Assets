#################################################
Minecraft Pi Edition Reborn (MCPI-Reborn) README:
#################################################

# MCPI Files + Locations
/home/pi/.minecraft-pi/games/com.mojang/minecraftWorlds/*
/home/pi/.minecraft-pi/server.properties
/home/pi/.minecraft-pi/servers.txt
/home/pi/.minecraft-pi/overrides

# MCPI Sound
Minecraft's sound is NOT Distributed with Minecraft Pi Edition Reborn (MCPI-Reborn).
Sound can found in MinecraftPocketEdition v0.6.12 APK.
File Required: libminecraftpe.so

EXTRACT [libminecraftpe.so] from APK and Place into:
/home/pi/.minecraft-pi/overrides/libminecraftpe.so

Recommend [PE-a0.11.1-2-x86.apk]:
http://archive.org/download/MCPEAlpha/PE-a0.11.1-2-x86.apk

###################################################
Minecraft Pi Edition Reborn (MCPI-Reborn) Controls:
###################################################

 https://github.com/MCPI-Revival/minecraft-pi-reborn/blob/master/docs/CONTROLS.md

# In-Game Controls

## Keyboard & Mouse
| Action | Function |
| --- | --- |
| <kbd> W </kbd> | Move Forward |
| <kbd> A </kbd> | Move Left |
| <kbd> S </kbd> | Move Backward |
| <kbd> D </kbd> | Move Right |
| <kbd> Space </kbd> | Jump |
| <kbd> Shift </kbd> | Sneak |
| <kbd> E </kbd> | Open Inventory |
| <kbd> Q </kbd> | Drop Item |
| <kbd> Ctrl </kbd>+<kbd>Q</kbd> | Drop Item Stack |
| <kbd> 1 </kbd>-<kbd>9</kbd> | Select Item In Toolbar/Hotbar |
| <kbd> Escape </kbd> | Pause |
| <kbd> Tab </kbd> | Lock/Unlock Mouse |
| <kbd> F11 </kbd> | Fullscreen |
| <kbd> F2 </kbd> | Screenshot |
| <kbd> F1 </kbd> | Hide GUI |
| <kbd> F5 </kbd> | Change Perspective |
| <kbd> T </kbd> | Open Chat |
| Mouse Movement | Camera Control |
| Scroll Wheel | Cycle Selected Item In Toolbar |
| Left-CLick | Attack/Destroy |
| Right-Click | Use Item/Place Block |

# QJoyPad Controls (if applicable)

QJoyPad [Mouse Hor/Vert] Mapped to: JoyPad RStick (Axis4Hor/Axis5Vert)
QJoyPad [Mouse1 LClick] Mapped to: JoyPad RTrigger (Axis6) + R3Press (Button11)
QJoyPad [Mouse3 RClick] Mapped to: JoyPad LTrigger (Axis3)
QJoyPad [F11 Key] Mapped to: JoyPad Pair Button (Button9)

#####################################################
Minecraft Pi Edition Reborn (MCPI-Reborn) Repo Seeds:
#####################################################

https://mcpi-revival.github.io/mcpi-repo/seeds/

Category 	Seed 	Description

SurvivalIsland 	1616313507 	Survival Island with grass, trees, and beach
SurvivalIsland 	93610339 	Survival Island with a lagoon and forest
Snowy Biome 	3029700 	Large Snowy biome with forest hills nearby
Snowy Biome 	1616133250 	Snowy hills with huge floating island nearby
Snowy Biome 	1610791506 	Huge frozen lake surrounded by snowy hills
Snowy Biome 	1610825737 	Vast Snowy Plains Biome
Snowy Biome 	1614373761 	Vast Snowy Plains Biome
Snowy Biome 	1968523703 	Huge frozen lake surrounded by snowy plains
Snowy Biome 	-1354664164 	Huge frozen lake off shore from snowy taiga
Forest Biome 	1616809412 	Forest canyon with water running through
Forest Biome 	1616962635 	Forest banks and islands overlooking lake
Forest Biome 	1616615941 	Forest Coastline
Forest Biome 	1617378393 	Forest valley with ponds
Water Features 	1617274108 	Steep hills with underground water-tunnels
Water Features 	1617754432 	Cove featuring lagoons
Water Features 	1643153847 	Cool, long river
Water Features 	1643155162 	Frozen part of river, big ocean, lakes and 2 block water source
Plains Biome 	1616809535 	Flat grassy plains with water and few trees
Plains Biome 	1617521647 	Flat grassy plains with little water or trees
Plains Biome 	1617665494 	Coastal plain with many flowers
Overhangs / Floating Islands 	3396408 	Few overhangs with steep hills nearby
Overhangs / Floating Islands 	-1965077007 	Many overhangs with lake beneath
Overhangs / Floating Islands 	1616133250 	Huge floating island nearby
Mountains 	1643154840 	Big sand mountain with lava pool nearby
Mountains 	1643154721 	Big mountains near world border

EXAMPLE: [/home/pi/.minecraft-pi/server.properties]

# World Seed (Blank = Random Seed)
seed=1643154721
