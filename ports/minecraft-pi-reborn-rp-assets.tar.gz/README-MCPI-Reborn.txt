#################################################
Minecraft Pi Edition Reborn (MCPI-Reborn) README:
#################################################

# MCPI Files + Locations
/home/pi/.minecraft-pi/games/com.mojang/minecraftWorlds/*
/home/pi/.minecraft-pi/server.properties
/home/pi/.minecraft-pi/servers.txt
/home/pi/.minecraft-pi/overrides

# MCPI Sound
Minecraft's sound is NOT Distributed with Minecraft Pi Edition Reborn (MCPI-Reborn).
Sound can found in MinecraftPocketEdition v0.6.12 APK.
File Required: libminecraftpe.so

EXTRACT [libminecraftpe.so] from APK and Place into:
/home/pi/.minecraft-pi/overrides/libminecraftpe.so

Recommend [PE-a0.11.1-2-x86.apk]:
http://archive.org/download/MCPEAlpha/PE-a0.11.1-2-x86.apk

https://download1638.mediafire.com/skz80sv2sm8ge7rJ5w-lvGDpGxeSk-GQ_SxwbFNb2q_HiDNpJLi-EpkOlkQv223ObBOmrJQ0eh86J_lvgdL9GzWMC4820cdMAeTCs4w9zVX9LkUhHdHanUaYOHqKwFmltj4gnfnWnvadpAYssR7u3bHlo93Y3FaKprQnWlwCYUtFrw/g2dxfbjbgwxz931/PE-a0.11.1-2-x86.apk

###################################################
Minecraft Pi Edition Reborn (MCPI-Reborn) Controls:
###################################################

https://github.com/MCPI-Revival/minecraft-pi-reborn/blob/master/docs/CONTROLS.md

## Keyboard & Mouse
| Action | Function |
| --- | --- |
| <kbd> W </kbd> | Move Forward |
| <kbd> A </kbd> | Move Left |
| <kbd> S </kbd> | Move Backward |
| <kbd> D </kbd> | Move Right |
| <kbd> Space </kbd> | Jump |
| <kbd> Shift </kbd> | Sneak |
| <kbd> E </kbd> | Open Inventory |
| <kbd> Q </kbd> | Drop Item |
| <kbd> Ctrl+Q</kbd> | Drop Item Stack |
| <kbd> 1-9</kbd> | Select Item In Toolbar/Hotbar |
| <kbd> Escape </kbd> | Pause |
| <kbd> Tab </kbd> | Lock/Unlock Mouse |
| <kbd> F11 </kbd> | Fullscreen |
| <kbd> F2 </kbd> | Screenshot |
| <kbd> F1 </kbd> | Hide GUI |
| <kbd> F5 </kbd> | Change Perspective |
| <kbd> T </kbd> | Open Chat |
| Mouse Movement | Camera Control |
| Scroll Wheel | Cycle Selected Item In Toolbar |
| Left-CLick | Attack/Destroy |
| Right-Click | Use Item/Place Block |

#####################################################
# QJoyPad Mappings (if applicable):
#####################################################
LStick-Directional [WASD] {Movement Forward/Back + Strafing Left/Right}
RStick-Directional [Mouse Hor/Vert] {Looking Up/Down/Left/Right}

LStick-Press [Shift] {Sneak}
RStick-Press [Ctrl] {Use with ~Q~ to Drop Item Stack}

Start [Escape] {Pause/Menu}
Select [F3] {Show/Hide Location + Stats}

Pair/Middle [F11] {Fullscreen}

DPadU [F5] {Change Perspective}
DpadD [Q] {Drop Item}
DPadL [F1] {Show/Hide GUI}
DpadR [T] {Open Chat}

L1 [Mouse4] {Inventory L/U}
R1 [Mouse5] {Inventory R/D} *RapidFire*

R2Trigger [Mouse1 LClick] {Attack/Destroy}
L2Trigger [Mouse3 RClick] {Use Item/Place Block}

ButtonNorth [E] {Open Inventory}
ButtonSouth [Space] {Jump}
ButtonEast [Shift] {Sneak} *StickyKey*
ButtonWest [Shift] {Sneak}

#####################################################
Minecraft Pi Edition Reborn (MCPI-Reborn) Repo Seeds:
#####################################################

https://mcpi-revival.github.io/mcpi-repo/seeds/

Category 	Seed 	Description

SurvivalIsland 	1616313507 	Survival Island with grass, trees, and beach
SurvivalIsland 	93610339 	Survival Island with a lagoon and forest
Snowy Biome 	3029700 	Large Snowy biome with forest hills nearby
Snowy Biome 	1616133250 	Snowy hills with huge floating island nearby
Snowy Biome 	1610791506 	Huge frozen lake surrounded by snowy hills
Snowy Biome 	1610825737 	Vast Snowy Plains Biome
Snowy Biome 	1614373761 	Vast Snowy Plains Biome
Snowy Biome 	1968523703 	Huge frozen lake surrounded by snowy plains
Snowy Biome 	-1354664164 	Huge frozen lake off shore from snowy taiga
Forest Biome 	1616809412 	Forest canyon with water running through
Forest Biome 	1616962635 	Forest banks and islands overlooking lake
Forest Biome 	1616615941 	Forest Coastline
Forest Biome 	1617378393 	Forest valley with ponds
Water Features 	1617274108 	Steep hills with underground water-tunnels
Water Features 	1617754432 	Cove featuring lagoons
Water Features 	1643153847 	Cool, long river
Water Features 	1643155162 	Frozen part of river, big ocean, lakes and 2 block water source
Plains Biome 	1616809535 	Flat grassy plains with water and few trees
Plains Biome 	1617521647 	Flat grassy plains with little water or trees
Plains Biome 	1617665494 	Coastal plain with many flowers
Overhangs / Floating Islands 	3396408 	Few overhangs with steep hills nearby
Overhangs / Floating Islands 	-1965077007 	Many overhangs with lake beneath
Mountains 	1643154840 	Big sand mountain with lava pool nearby
Mountains 	1643154721 	Big mountains near world border

EXAMPLE: [/home/pi/.minecraft-pi/server.properties]

# World Seed (Blank = Random Seed)
seed=1616313507

#####################################################
Minecraft: Pi Edition Complete Item List:
#####################################################

https://mcpirevival.miraheze.org/wiki/Minecraft:_Pi_Edition_Complete_Item_List

Credits to Wallee#8314 on Discord for generating this and crashing his game 200 times in the name of science!
This list contains the unofficial item name and it's id.
The only way to get them in your inventory is to edit your world's level.dat file with (MCPIedit), or use a custom MCPI-Reborn mod.

Iron Shovel: 256
Iron Pickaxe: 257
Iron Axe: 258
Flint Steel: 259
Apple: 260
Bow: 261
Arrow: 262
Coal: 263
Diamond: 264
Iron Ingot: 265
Gold Ingot: 266
Iron Sword: 267
Wooden Sword: 268
Wooden Shovel: 269
Wooden Pickaxe: 270
Wooden Axe: 271
Stone Sword: 272
Stone Shovel: 273
Stone Pickaxe: 274
Stone Axe: 275
Diamond Sword: 276
Diamond Shovel: 277
Diamond Pickaxe: 278
Diamond Axe: 279
Stick: 280
Bowl: 281
Mushroom Stew: 282
Gold Sword: 283
Gold Shovel: 284
Gold Pickaxe: 285
Gold Axe: 286
String: 287
Feather: 288
Gunpowder: 289
Wooden Hoe: 290
Stone Hoe: 291
Iron Hoe: 292
Diamond Hoe: 293
Gold Hoe: 294
Seeds: 295
Wheat: 296
Bread: 297
Leather Cap: 298
Leather Tunic: 299
Leather Pants: 300
Leather Boots: 301
Chain Helmet: 302
Chain Chestplate: 303
Chain Leggings: 304
Chain Boots: 305
Iron Helmet: 306
Iron Chestplate: 307
Iron Leggings: 308
Iron Boots: 309
Diamond Helmet: 310
Diamond Chestplate: 311
Diamond Leggings: 312
Diamond Boots: 313
Gold Helmet: 314
Gold Chestplate: 315
Gold Leggings: 316
Gold Boots: 317
Flint: 318
Raw Porkchop: 319
Cooked Porkchop: 320
Painting: 321
Sign: 323
Wooden Door: 324
Iron Door: 330
Snowball: 332
Leather: 334
Clay Brick: 336
Clay: 337
Sugar Cane: 338
Paper: 339
Book: 340
Slimeball: 341
Egg: 344
Compass: 345
Clock: 347
Glowstone Dust: 348
Dye: 351
Bone: 352
Sugar: 353
Bed: 355
Shears: 359
Melon: 360
Melon Seeds: 362
Raw Beef: 363
Steak: 364
Raw Chicken: 365
Cooked Chicken: 366
Nether Brick: 405
Nether Quartz: 406
Camera: 456
