#!/bin/bash

pushd /home/pi/.minecraft-pi

# Run mcpiedit in isolated virtual environment
source envmcpiedit/bin/activate
/home/pi/.mcpiedit/mcpiedit
deactivate

popd
