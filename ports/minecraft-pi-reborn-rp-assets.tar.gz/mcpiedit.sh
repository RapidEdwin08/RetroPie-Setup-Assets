#!/bin/bash

# Run mcpiedit in isolated virtual environment
source /home/pi/.mcpiedit/envmcpiedit/bin/activate
/home/pi/.mcpiedit/mcpiedit
deactivate
