#!/bin/bash
# https://github.com/RapidEdwin08/

# --server will call Dialog.sh withOUT retropiemenu launch when called from .desktop Shortcut
# --es-server will call Dialog.sh with RetroPie-Setup/retropie_packages.sh retropiemenu launch for JoyPad Support when called from ES
# (No Argument) will Run normal AppImage with the --server argument to generate the world and [server.properties] in current directory.

app_img=minecraft-pi-reborn-client-2.5.4-amd64.AppImage
srv_app_img=minecraft-pi-reborn-server-2.5.4-amd64.AppImage
app_dir=/opt/retropie/ports/minecraft-pi-reborn
cfg_app_dir=/home/pi/.minecraft-pi

#	Button 3: key 135	#	Button 4: key 26	#	Button 7: key 9
qjoyLAYOUT="Minecraft"
qjoyLYT=$(
echo '# QJoyPad 4.3 Layout File

Joystick 1 {
	Axis 3: dZone 25309, xZone 3163, +mouse 3, -key 0
	Axis 4: gradient, maxSpeed 3, tCurve 0, mouse+h
	Axis 5: gradient, maxSpeed 3, tCurve 0, mouse+v
	Axis 6: dZone 25309, xZone 3163, +mouse 1, -key 0
	Button 9: key 95
	Button 11: mouse 1
}
')

# Create QJoyPad.lyt if needed
if [ ! -f "$HOME/.qjoypad3/$qjoyLAYOUT.lyt" ]; then echo "$qjoyLYT" > "$HOME/.qjoypad3/$qjoyLAYOUT.lyt"; fi

pkill qemu-arm # qemu-arm may linger in Server mode

if [[ "$1" == *"--server"* ]]; then
	echo "$app_dir/$srv_app_img" >> /dev/shm/runcommand.log
	pushd $cfg_app_dir
	$app_dir/$srv_app_img &
	bash /opt/retropie/ports/minecraft-pi-reborn/minecraft-es-server.sh
elif [[ "$1" == *"--es-server"* ]]; then
	# Call additional Script using RetroPie-Setup for Server Mode GUI with JoyPad Support & Start Server
	sudo /home/pi/RetroPie-Setup/retropie_packages.sh retropiemenu launch '/opt/retropie/ports/minecraft-pi-reborn/minecraft-es-server.sh' </dev/tty > /dev/tty &
	echo "$app_dir/$srv_app_img" >> /dev/shm/runcommand.log
	pushd $cfg_app_dir
	$app_dir/$srv_app_img
else
	if [ ! -f /home/pi/.minecraft-pi/overrides/libminecraftpe.so ]; then #DisplayMissingSound
		echo "***N0TICE***  You will NOT have SOUND until you Install the SOUND FILE [$HOME/.minecraft-pi/overrides/libminecraftpe.so] 1st!" # /dev/shm/runcommand.log is just fine...
        echo Sound can found in MinecraftPocketEdition v0.6.12 APK.
        echo Recommend [PE-a0.11.1-2-x86.apk]: archive.org/download/MCPEAlpha/PE-a0.11.1-2-x86.apk
        echo EXTRACT [libminecraftpe.so] from APK and Place into:
        echo $HOME/.minecraft-pi/overrides/libminecraftpe.so
	fi

	# Run qjoypad
	pkill -15 qjoypad > /dev/null 2>&1
	rm /tmp/qjoypad.pid > /dev/null 2>&1
	echo "qjoypad "$qjoyLAYOUT" &" >> /dev/shm/runcommand.info
	qjoypad "$qjoyLAYOUT" &

	pushd $cfg_app_dir
	# Run normal AppImage with the --server argument to generate the world and [server.properties] in current directory.
	VC4_DEBUG=always_sync $app_dir/$app_img --server
fi

popd

pkill qemu-arm # qemu-arm may linger in Server mode

# Kill qjoypad
pkill -15 qjoypad > /dev/null 2>&1; rm /tmp/qjoypad.pid > /dev/null 2>&1

# Restart qjoypad IF DTWPID qjoypad@Desktop is Enabled + startx is running
if [[ -f /etc/xdg/autostart/qjoypad-start.desktop ]] && pgrep -f startx &> /dev/null 2>&1; then qjoypad-start > /dev/null 2>&1; fi
