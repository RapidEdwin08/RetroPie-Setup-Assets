#!/bin/bash
# https://github.com/RapidEdwin08/

# --server will call Dialog.sh withOUT retropiemenu launch when called from .desktop Shortcut
# --es-server will call Dialog.sh with RetroPie-Setup/retropie_packages.sh retropiemenu launch for JoyPad Support when called from ES
# (No Argument) will Run normal AppImage with the $* all arguments

app_img=minecraft-pi-reborn-3.0.3-arm64.AppImage
app_dir=/opt/retropie/ports/minecraft-pi-reborn
cfg_app_dir=/home/pi/.minecraft-pi

# Similar to Minecraft Playstation Controls
qjoyLAYOUT="Minecraft-v3"
qjoyLYT=$(
echo '# QJoyPad 4.3 Layout File

Joystick 1 {
	Axis 1: dZone 20000, +key 40, -key 38
	Axis 2: dZone 7250, +key 39, -key 25
	Axis 3: throttle+, dZone 25000, xZone 32767, +mouse 3, -key 0
	Axis 4: gradient, dZone 7250, maxSpeed 6, tCurve 0, mouse+h
	Axis 5: gradient, dZone 7250, maxSpeed 6, tCurve 0, mouse+v
	Axis 6: throttle+, dZone 25000, xZone 32767, +mouse 1, -key 0
	Axis 7: +key 28, -key 67
	Axis 8: +key 24, -key 71
	Button 1: key 65
	Button 2: sticky, key 50
	Button 3: key 50
	Button 4: key 26
	Button 5: mouse 4
	Button 6: rapidfire, mouse 5
	Button 7: key 69
	Button 8: key 9
	Button 9: key 95
	Button 10: key 50
	Button 11: key 37
	Button 12: key 67
	Button 13: key 28
	Button 14: key 71
	Button 15: key 24
}
')

# Create QJoyPad.lyt if needed
if [ ! -f "$HOME/.qjoypad3/$qjoyLAYOUT.lyt" ]; then echo "$qjoyLYT" > "$HOME/.qjoypad3/$qjoyLAYOUT.lyt"; fi

##pkill qemu-arm # qemu-arm may linger in Server mode # v2

if [[ "$1" == *"--server"* ]]; then
	pushd $cfg_app_dir
	$app_dir/$app_img --server &
	bash /opt/retropie/ports/minecraft-pi-reborn/minecraft-es-server.sh
elif [[ "$1" == *"--es-server"* ]]; then
	# Call additional Script using RetroPie-Setup for Server Mode GUI with JoyPad Support & Start Server
	sudo /home/pi/RetroPie-Setup/retropie_packages.sh retropiemenu launch '/opt/retropie/ports/minecraft-pi-reborn/minecraft-es-server.sh' </dev/tty > /dev/tty &
	pushd $cfg_app_dir
	$app_dir/$app_img --server
else
	if [ ! -f /home/pi/.minecraft-pi/overrides/libminecraftpe.so ]; then #DisplayMissingSound
		echo "***N0TICE***  You will NOT have SOUND until you Install the SOUND FILE [$HOME/.minecraft-pi/overrides/libminecraftpe.so] 1st!" # /dev/shm/runcommand.log is just fine...
        echo Sound can found in MinecraftPocketEdition v0.6.12 APK.
        echo Recommend [PE-a0.11.1-2-x86.apk]: https://archive.org/download/MCPEAlpha/PE-a0.11.1-2-x86.apk
        echo Alternate: https://dn721800.ca.archive.org/0/items/minecraft-pocket-edition-library/Minecraft%20PE%200.9.0-build5.apk
        echo Alternate: https://download1638.mediafire.com/skz80sv2sm8ge7rJ5w-lvGDpGxeSk-GQ_SxwbFNb2q_HiDNpJLi-EpkOlkQv223ObBOmrJQ0eh86J_lvgdL9GzWMC4820cdMAeTCs4w9zVX9LkUhHdHanUaYOHqKwFmltj4gnfnWnvadpAYssR7u3bHlo93Y3FaKprQnWlwCYUtFrw/g2dxfbjbgwxz931/PE-a0.11.1-2-x86.apk
        echo EXTRACT [libminecraftpe.so] from APK and Place into:
        echo $HOME/.minecraft-pi/overrides/libminecraftpe.so
	fi

	# Run qjoypad
	pkill -15 qjoypad > /dev/null 2>&1
	rm /tmp/qjoypad.pid > /dev/null 2>&1
	echo "qjoypad "$qjoyLAYOUT" &" >> /dev/shm/runcommand.info
	qjoypad "$qjoyLAYOUT" &

	if [ -f "$app_dir/mcpiedit.on" ]; then
		echo Running MCPIedit in isolated virtual environment
		source /home/pi/.mcpiedit/envmcpiedit/bin/activate
		/home/pi/.mcpiedit/mcpiedit
		deactivate
	fi

	# Run AppImage
	pushd $cfg_app_dir
	VC4_DEBUG=always_sync $app_dir/$app_img $*
fi

popd

##pkill qemu-arm # qemu-arm may linger in Server mode # v2

# Kill qjoypad
pkill -15 qjoypad > /dev/null 2>&1; rm /tmp/qjoypad.pid > /dev/null 2>&1

# Restart qjoypad IF DTWPID qjoypad@Desktop is Enabled + startx is running
if [[ -f /etc/xdg/autostart/qjoypad-start.desktop ]] && pgrep -f startx &> /dev/null 2>&1; then qjoypad-start > /dev/null 2>&1; fi
