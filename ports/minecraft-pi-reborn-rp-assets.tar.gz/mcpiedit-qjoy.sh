#!/bin/bash
# https://github.com/RapidEdwin08/

#	Button 3: key 135	#	Button 4: key 26	#	Button 7: key 9
qjoyLAYOUT="Minecraft-v3"
qjoyLYT=$(
echo '# QJoyPad 4.3 Layout File

Joystick 1 {
	Axis 1: dZone 20000, +key 40, -key 38
	Axis 2: dZone 7250, +key 39, -key 25
	Axis 3: throttle+, dZone 25000, xZone 32767, +mouse 3, -key 0
	Axis 4: gradient, dZone 7250, maxSpeed 6, tCurve 0, mouse+h
	Axis 5: gradient, dZone 7250, maxSpeed 6, tCurve 0, mouse+v
	Axis 6: throttle+, dZone 25000, xZone 32767, +mouse 1, -key 0
	Axis 7: +key 28, -key 67
	Axis 8: +key 24, -key 71
	Button 1: key 65
	Button 2: sticky, key 50
	Button 3: key 50
	Button 4: key 26
	Button 5: mouse 4
	Button 6: rapidfire, mouse 5
	Button 7: key 69
	Button 8: key 9
	Button 9: key 95
	Button 10: key 50
	Button 11: key 37
	Button 12: key 67
	Button 13: key 28
	Button 14: key 71
	Button 15: key 24
}
')

# Create QJoyPad.lyt if needed
if [ ! -f "$HOME/.qjoypad3/$qjoyLAYOUT.lyt" ]; then echo "$qjoyLYT" > "$HOME/.qjoypad3/$qjoyLAYOUT.lyt"; fi

# Run qjoypad
pkill -15 qjoypad > /dev/null 2>&1
rm /tmp/qjoypad.pid > /dev/null 2>&1
echo "qjoypad "$qjoyLAYOUT" &" >> /dev/shm/runcommand.info
qjoypad "$qjoyLAYOUT" &

# Run mcpiedit in isolated virtual environment
source /home/pi/.mcpiedit/envmcpiedit/bin/activate
/home/pi/.mcpiedit/mcpiedit
deactivate

# Kill qjoypad
pkill -15 qjoypad > /dev/null 2>&1; rm /tmp/qjoypad.pid > /dev/null 2>&1

# Restart qjoypad IF DTWPID qjoypad@Desktop is Enabled + startx is running
if [[ -f /etc/xdg/autostart/qjoypad-start.desktop ]] && pgrep -f startx &> /dev/null 2>&1; then qjoypad-start > /dev/null 2>&1; fi
