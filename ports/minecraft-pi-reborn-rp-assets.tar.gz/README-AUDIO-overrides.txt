Minecraft's sound is NOT Distributed with Minecraft Pi Edition Reborn (MCPI-Reborn).
Sound can found in MinecraftPocketEdition v0.6.12 APK.
File Required: libminecraftpe.so

EXTRACT [libminecraftpe.so] from APK and Place into:
/home/pi/.minecraft-pi/overrides/libminecraftpe.so

Recommend [PE-a0.11.1-2-x86.apk]:
http://archive.org/download/MCPEAlpha/PE-a0.11.1-2-x86.apk
