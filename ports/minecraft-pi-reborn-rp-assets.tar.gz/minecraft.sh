#!/bin/bash

app_img=minecraft-pi-reborn-client-2.5.4-amd64.AppImage
srv_app_img=minecraft-pi-reborn-server-2.5.4-amd64.AppImage
app_dir=/opt/retropie/ports/minecraft-pi-reborn
cfg_app_dir=/home/pi/.minecraft-pi

#=======================================
minecraftLOGO=$(
echo "IP: $(hostname -I | tr -d ' ') / `curl -4 icanhazip.com 2>/dev/null | awk '{print $NF; exit}'`
$(lsof -i -P -n | grep qemu-arm | awk '{print $8, $9}')

 [/home/pi/.minecraft-pi/server.properties]:
$(cat /home/pi/.minecraft-pi/server.properties  | grep = | grep -v \#)

* Press [CTRL-C] to KILL SERVER and EXIT... *
"
)
#=======================================

pkill qemu-arm # qemu-arm may linger in Server mode

if [[ "$1" == *"--server"* ]]; then
	#echo "$minecraftLOGO"
	echo "$app_dir/$srv_app_img" >> /dev/shm/runcommand.log
	pushd $cfg_app_dir
	$app_dir/$srv_app_img &
	bash /opt/retropie/ports/minecraft-pi-reborn/minecraft-es-server.sh
elif [[ "$1" == *"--es-server"* ]]; then
	# Call additional Script using RetroPie-Setup for Server Mode GUI with JoyPad Support & Start Server
	sudo /home/pi/RetroPie-Setup/retropie_packages.sh retropiemenu launch '/opt/retropie/ports/minecraft-pi-reborn/minecraft-es-server.sh' </dev/tty > /dev/tty &
	echo "$app_dir/$srv_app_img" >> /dev/shm/runcommand.log
	pushd $cfg_app_dir
	$app_dir/$srv_app_img
else
	if [ ! -f /home/pi/.minecraft-pi/overrides/libminecraftpe.so ]; then #DisplayMissingSound
		echo "***N0TICE***  You will NOT have SOUND until you Install the SOUND FILE [/home/pi/.minecraft-pi/overrides/libminecraftpe.so] 1st!" # /dev/shm/runcommand.log is just fine...
	fi
	pushd $cfg_app_dir
	# Run normal AppImage with the --server argument to generate the world and [server.properties] in current directory.
	$app_dir/$app_img --server
fi

popd

pkill qemu-arm # qemu-arm may linger in Server mode
