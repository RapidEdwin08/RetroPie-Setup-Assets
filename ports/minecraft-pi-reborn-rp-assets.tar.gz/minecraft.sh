#!/bin/bash

# --server will call Dialog.sh withOUT retropiemenu launch when called from .desktop Shortcut
# --es-server will call Dialog.sh with RetroPie-Setup/retropie_packages.sh retropiemenu launch for JoyPad Support when called from ES
# (No Argument) will Run normal AppImage with the --server argument to generate the world and [server.properties] in current directory.

app_img=minecraft-pi-reborn-3.0.3-arm64.AppImage
app_dir=/opt/retropie/ports/minecraft-pi-reborn
cfg_app_dir=/home/pi/.minecraft-pi

##pkill qemu-arm # qemu-arm may linger in Server mode # v2

if [[ "$1" == *"--server"* ]]; then
	pushd $cfg_app_dir
	$app_dir/$app_img --server &
	bash /opt/retropie/ports/minecraft-pi-reborn/minecraft-es-server.sh
elif [[ "$1" == *"--es-server"* ]]; then
	# Call additional Script using RetroPie-Setup for Server Mode GUI with JoyPad Support & Start Server
	sudo /home/pi/RetroPie-Setup/retropie_packages.sh retropiemenu launch '/opt/retropie/ports/minecraft-pi-reborn/minecraft-es-server.sh' </dev/tty > /dev/tty &
	pushd $cfg_app_dir
	$app_dir/$app_img --server
else
	if [ ! -f /home/pi/.minecraft-pi/overrides/libminecraftpe.so ]; then #DisplayMissingSound
		echo "***N0TICE***  You will NOT have SOUND until you Install the SOUND FILE [$HOME/.minecraft-pi/overrides/libminecraftpe.so] 1st!" # /dev/shm/runcommand.log is just fine...
        echo Sound can found in MinecraftPocketEdition v0.6.12 APK.
        echo Recommend [PE-a0.11.1-2-x86.apk]: https://archive.org/download/MCPEAlpha/PE-a0.11.1-2-x86.apk
        echo Alternate: https://dn721800.ca.archive.org/0/items/minecraft-pocket-edition-library/Minecraft%20PE%200.9.0-build5.apk
        echo Alternate: https://download1638.mediafire.com/skz80sv2sm8ge7rJ5w-lvGDpGxeSk-GQ_SxwbFNb2q_HiDNpJLi-EpkOlkQv223ObBOmrJQ0eh86J_lvgdL9GzWMC4820cdMAeTCs4w9zVX9LkUhHdHanUaYOHqKwFmltj4gnfnWnvadpAYssR7u3bHlo93Y3FaKprQnWlwCYUtFrw/g2dxfbjbgwxz931/PE-a0.11.1-2-x86.apk
        echo EXTRACT [libminecraftpe.so] from APK and Place into:
        echo $HOME/.minecraft-pi/overrides/libminecraftpe.so
	fi

	# Run AppImage
	pushd $cfg_app_dir
	VC4_DEBUG=always_sync $app_dir/$app_img $*
fi

popd

##pkill qemu-arm # qemu-arm may linger in Server mode # v2

# kill instances of minecraft-pi
PIDrunncommandSH=$(ps -eaf | grep "minecraft-pi" | awk '{print $2}')
kill $PIDrunncommandSH > /dev/null 2>&1
