#!/bin/bash

app_img=minecraft-pi-reborn-client-2.5.4-amd64.AppImage
srv_app_img=minecraft-pi-reborn-server-2.5.4-amd64.AppImage
app_dir=/opt/retropie/ports/minecraft-pi-reborn
srv_app_dir=/home/pi/.minecraft-pi

# Start Minecraft Server or Client
if [[ "$1" == *"--server"* ]]; then
	pushd $srv_app_dir
	$app_dir/$srv_app_img
else
	if [ ! -f /home/pi/.minecraft-pi/overrides/libminecraftpe.so ]; then #DisplayMissingSound
		echo "***N0TICE***  You will NOT have SOUND until you Install the SOUND FILE [/home/pi/.minecraft-pi/overrides/libminecraftpe.so] 1st!" # /dev/shm/runcommand.log is just fine...
	fi
	pushd $srv_app_dir
	# Run normal AppImage with the --server argument to generate the world and [server.properties] in current directory.
	$app_dir/$app_img --server
fi
popd
