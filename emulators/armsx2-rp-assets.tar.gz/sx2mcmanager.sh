#!/bin/bash
# https://github.com/RapidEdwin08

# ACTIVATE MemoryCard Manager by selecting Emulator with +mcmanager in its name
# Examples: [aethersx2+mcmanager] [armsx2-sdl+mcmanager] [pcsx2+mcmanager]

# UPDATES [PCSX2.ini] MemoryCard Slot1_Filename to 'Mcd001 PS2-ROM-NAME.ps2' on [runcommand-onlaunch]
# RETURNS [PCSX2.ini] MemoryCard Slot1_Filename to 'Mcd001.ps2' on [runcommand-onend]

# ADD to [runcommand-onlaunch.sh] to SET Individual MemoryCard - Slot1_Filename = PS2-ROM-(MC)-NAME.ps2
##if [[ "$1" == "ps2" ]]; then bash /opt/retropie/configs/ps2/mcmanager.sh onlaunch; fi #For Use With [mcmanager]

# ADD to [runcommand-onend.sh] to RESTORE Default MC - Slot1_Filename = Mcd001.ps2
##if [ "$(head -1 /dev/shm/runcommand.info)" == "ps2" ]; then bash /opt/retropie/configs/ps2/mcmanager.sh onend; fi #For Use With [mcmanager]

romNAME="$(basename "$(head -3 /dev/shm/runcommand.info | tail +3)" )"
mcNAME="Mcd001 ${romNAME%.*}.ps2"
runCMDlog=/dev/shm/runcommand.log
sx2INI=~/.config/aethersx2/inis/PCSX2.ini
if [[ "$(head -2 /dev/shm/runcommand.info | tail +2)" == "armsx2"* ]]; then sx2INI=~/.config/ARMSX2/inis/PCSX2.ini; fi
if [[ -f ~/.config/PCSX2/inis/PCSX2.ini ]]; then sx2INI=~/.config/PCSX2/inis/PCSX2.ini; fi
if [[ -f /opt/retropie/configs/ps2/Config/inis/PCSX2.ini ]]; then sx2INI=/opt/retropie/configs/ps2/Config/inis/PCSX2.ini; fi
if [[ ! -f "$sx2INI.b4mcmanager" ]]; then cp "$sx2INI" "$sx2INI.b4mcmanager"; fi # Backup PCSX2.ini

# Restore Slot1 to Default Mcd001.ps2 if EMULATOR NOT +mcmanager
if [[ ! "$(head -2 /dev/shm/runcommand.info | tail +2)" == *"+mcmanager"* ]]; then
	if [[ "$(cat $sx2INI | grep ^Slot1_Filename | grep Mcd001.ps2)" == '' ]]; then
		echo [+mcmanager] CHECK [$sx2INI]: $(cat $sx2INI | grep ^Slot1_Filename) >> $runCMDlog
		echo [+mcmanager] RESTORE Default PS2 MemoryCard Name: Mcd001.ps2 >> $runCMDlog
		# Slot1_Filename = Mcd001.ps2
		sed -i "s/^Slot1_Filename\ =.*/Slot1_Filename\ =\ Mcd001.ps2/g" $sx2INI
	fi
	exit 0 # Do Nothing if EMULATOR NOT +mcmanager and Slot1 Setting in PCSX2.ini already Default
fi

# onlaunch: Set Individual PS2 MemoryCard if EMULATOR IS +mcmanager
if [ "$1" == "onlaunch" ]; then
	echo [+mcmanager] UPDATE PS2 MemoryCard Name: $mcNAME >> $runCMDlog
	# Slot1_Filename = $romNAME.ps2
	sed -i "s/^Slot1_Filename\ =.*/Slot1_Filename\ =\ $mcNAME/g" $sx2INI
fi

# onend: Restore Default PS2 MemoryCard if (MC)
if [ "$1" == "onend" ]; then
	echo [+mcmanager] RESTORE PS2 Default MemoryCard Name: Mcd001.ps2 >> $runCMDlog
	# Slot1_Filename = Mcd001.ps2
	sed -i "s/^Slot1_Filename\ =.*/Slot1_Filename\ =\ Mcd001.ps2/g" $sx2INI
fi

echo [+mcmanager] CHECK [$sx2INI]: $(cat $sx2INI | grep ^Slot1_Filename) >> $runCMDlog
