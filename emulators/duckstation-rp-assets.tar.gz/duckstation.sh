#!/bin/bash

app_img=DuckStation-x64.AppImage
app_dir=/opt/retropie/emulators/duckstation
pushd $app_dir

# Start Emulator
if [[ "$1" == '' ]] || [[ "$1" == *"+Start DuckStation"* ]]; then
	$app_dir/$app_img -bigpicture -fullscreen
elif [[ "$1" == *"--editor"* ]]; then
	$app_dir/$app_img -fullscreen
else
	if [ "$(ls ~/RetroPie/BIOS/SCPH*)" == '' ] && [ "$(ls ~/RetroPie/BIOS/scph*)" == '' ] && [ "$(ls ~/RetroPie/BIOS/psx*)" == '' ]; then #DisplayMissingBIOS
		#sudo fbi -T 2 -a -noverbose /opt/retropie/emulators/duckstation/PSXBIOSRequired.jpg > /dev/null 2>&1; sleep 7; sudo kill $(pgrep fbi) > /dev/null 2>&1; popd; exit 0
		echo "***N0TICE***  PSX BIOS NOT FOUND! You Need to Install PSX BIOS [~/RetroPie/BIOS/SCPH-XXXXX.bin] 1st!" # /dev/shm/runcommand.log is just fine...
	fi
        $app_dir/$app_img -bigpicture -fullscreen "$1"
fi
popd
