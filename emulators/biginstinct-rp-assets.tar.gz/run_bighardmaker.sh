#!/bin/bash

__user=
if [[ -z "$__user" ]]; then __user="$SUDO_USER"; [[ -z "$__user" ]] && __user="$(id -un)"; fi

bh_dir="/home/$__user/bighardmaker"
bh_log="$bh_dir/bighard.log"
bh_arch="$(uname -m | sed -e 's/86_//' | sed -e 's/aarch64/arm64/')"
bh_bin="$bh_dir/bighardmaker_$bh_arch"
bi_romdir="/home/$__user/RetroPie/roms/arcade"
bi_outdir="$bi_romdir/_bighardmaker"

bui_LOGO=$(
echo '
 __________.__       .___                 __  .__               __   
 \______   \__| ____ |   | ____   _______/  |_|__| ____   _____/  |_ 
  |    |  _/  |/ ___\|   |/    \ /  ___/\   __\  |/    \_/ ___\   __\
  |    |   \  / /_/  >   |   |  \\___ \  |  | |  |   |  \  \___|  |  
  |______  /__\___  /|___|___|  /____  > |__| |__|___|  /\___  >__|  
         \/  /_____/          \/     \/               \/     \/      
                            ___  __   ___ 
                           |   |/  | |   |
                           |   |   | |   |
                           |    <  \ |   |
                           |   | \  \|   |
                           |___|  \  |  /
                                   \  \/_/>
                                    \_/
')

readmeINFO=$(
echo "
$($bh_bin -help)

0) Provide {Arcade} Killer Instinct roms for BigHardMaker:
The Author has recommended [KI v1.5d] and [KI2 v1.4] (+CHD)
[kinst.zip ./kinst/kinst.chd] [kinst2.zip [./kinst2/kinst2.chd]

1) Prepare Killer Instinct roms for BigHardMaker:
$bh_dir/kinst.zip
$bh_dir/kinst/kinst.chd

$bh_dir/kinst2.zip
$bh_dir/kinst2/kinst2.chd

2) Create Killer Instinct roms with BigHardMaker:
$bh_bin

3) Copy {.bighard} Killer Instinct roms to:
$bi_romdir/kinst.bighard
$bi_romdir/kinst2.bighard
")

mainMENU()
{

# Menu
bigUImenu=$(dialog --no-collapse --title "BigHardUI for Rich Whitehouse's BigHardMaker" \
	--ok-label OK --cancel-label EXIT \
	--menu "            #  https://www.patreon.com/richwhitehouse  # $bui_LOGO" 25 75 20 \
	1 "READ ME 1ST!" \
	2 "SHOW [bighardmaker] Folder" \
	3 "RUN  [bighardmaker]" \
	4 "VIEW [bighard.log]" 2>&1>/dev/tty)
	
if [ ! "$bigUImenu" == '' ]; then
	# ReadMe
	if [ "$bigUImenu" == '1' ]; then
		dialog --no-collapse --title "https://www.richwhitehouse.com/ki" --ok-label Back --msgbox "$readmeINFO"  25 75
		mainMENU
	fi
	# View contents
	if [ "$bigUImenu" == '2' ]; then
		dialog --no-collapse --title "https://www.richwhitehouse.com/ki" --ok-label Back --msgbox "$(ls -lR --block-size=MB $bh_dir | grep -v ^drw | grep -v ^total | awk '{print $1,$5,$9}')"  25 75
	fi
	# Run
	if [ "$bigUImenu" == '3' ]; then
		if [[ ! -f "$bh_bin" ]]; then dialog --no-collapse --title "   [$bh_bin] NOT FOUND!   " --ok-label Continue --msgbox "\n[$bh_bin] IS MISSING..."  25 75; fi
		confRUNcmd=$(dialog --no-collapse --title "RUN [bighardmaker]" \
		--ok-label OK --cancel-label BACK \
		--menu "                          ? ARE YOU SURE ?                            \n            # $bh_bin #" 25 75 20 \
		1 " RUN  [bighardmaker] " \
		B " BACK" 2>&1>/dev/tty)
		if [ "$confRUNcmd" == '1' ]; then
			clear; echo RUNNING [bighardmaker] . . .
			echo "### BEGIN ### $(date)" > "$bh_log" 2>&1
			mkdir -p "$bi_outdir"
			$bh_bin -outdir "$bi_romdir/_bighardmaker" >> "$bh_log" 2>&1
			echo "###  END  ###  $(date)" >> "$bh_log" 2>&1
			chown $__user:$__user "$bh_log"
			chown -R $__user:$__user "$bi_romdir/_bighardmaker"
			dialog --no-collapse --title "   RUN [bighardmaker] COMPLETE   " --ok-label Back --msgbox "[$bh_log]: $(cat "$bh_log")"  25 75
		fi
	fi
	# View log
	if [ "$bigUImenu" == '4' ]; then
		if [[ ! -f "$bh_log" ]]; then echo Nothing to see here... > "$bh_log"; echo 'https://archive.org/download/mame_ki_ki2_roms_and_chds' >> "$bh_log"; echo '/mame_ki_ki2_roms_and_chds.zip' >> "$bh_log"; chown $__user:$__user "$bh_log"; fi
		dialog --no-collapse --title "   VIEW [bighard.log]   " --ok-label Back --msgbox "[$bh_log]: $(cat $bh_log)"  25 75
	fi
	# EXIT
	if [ "$bigUImenu" == 'X' ]; then
		tput reset
		exit 0
	fi
fi

if [ "$bigUImenu" == '' ]; then tput reset; exit 0; fi

mainMENU
}

if [[ ! -d "$bh_dir" ]]; then mkdir -p "$bh_dir"; chown -R $__user:$__user "$bh_dir"; fi
if [[ ! -f "$bh_bin" ]]; then dialog --no-collapse --title "   [$bh_bin] NOT FOUND!   " --ok-label Continue --msgbox "\n[$bh_bin] IS MISSING..."  25 75; bigUImenu; fi
mainMENU

tput reset
exit 0
