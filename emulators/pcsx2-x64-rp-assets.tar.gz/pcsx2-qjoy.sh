#!/bin/bash

#!/bin/bash
# https://github.com/RapidEdwin08/

qjoyLAYOUT="PCSX2"
qjoyLYT=$(
echo '# QJoyPad 4.3 Layout File

Joystick 1 {
	Axis 1: gradient, dZone 5768, maxSpeed 3, tCurve 0, mouse+h
	Axis 2: gradient, dZone 4615, maxSpeed 3, tCurve 0, mouse+v
	Axis 3: +key 111, -key 0
	Axis 4: gradient, dZone 5076, maxSpeed 3, tCurve 0, mouse+h
	Axis 5: gradient, dZone 4615, maxSpeed 3, tCurve 0, mouse+v
	Axis 6: +key 116, -key 0
	Axis 7: gradient, maxSpeed 2, tCurve 0, mouse+h
	Axis 8: gradient, maxSpeed 2, tCurve 0, mouse+v
	Button 1: mouse 1
	Button 2: mouse 3
	Button 3: mouse 1
	Button 4: mouse 3
	Button 5: mouse 1
	Button 6: mouse 3
	Button 7: key 9
	Button 8: key 36
	Button 9: key 9
	Button 10: mouse 1
	Button 11: mouse 3
	Button 12: key 113
	Button 13: key 114
	Button 14: key 111
	Button 15: key 116
}
')

# Create QJoyPad.lyt if needed
if [ ! -f "$HOME/.qjoypad3/$qjoyLAYOUT.lyt" ]; then echo "$qjoyLYT" > "$HOME/.qjoypad3/$qjoyLAYOUT.lyt"; sleep 2; fi

# Run qjoypad
pkill -15 qjoypad > /dev/null 2>&1
rm /tmp/qjoypad.pid > /dev/null 2>&1
echo "qjoypad "$qjoyLAYOUT" &" >> /dev/shm/runcommand.info
qjoypad "$qjoyLAYOUT" &

app_img=pcsx2-linux-appimage-x64-Qt.AppImage
app_dir=/opt/retropie/emulators/pcsx2-x64
pushd $app_dir

# Start Emulator
if [[ "$1" == '' ]] || [[ "$1" == *"+Start PCSX2"* ]]; then
	$app_dir/$app_img -bigpicture -fullscreen
elif [[ "$1" == *"--editor"* ]]; then
	$app_dir/$app_img -fullscreen
else
	if [ "$(ls ~/RetroPie/BIOS/SCPH*)" == '' ] && [ "$(ls ~/RetroPie/BIOS/scph*)" == '' ] && [ "$(ls ~/RetroPie/BIOS/ps2*)" == '' ]; then #DisplayMissingBIOS
		#sudo fbi -T 2 -a -noverbose $app_dir/PS2BIOSRequired.jpg > /dev/null 2>&1; sleep 7; sudo kill $(pgrep fbi) > /dev/null 2>&1; popd; exit 0
		echo "***N0TICE***  PS2 BIOS NOT FOUND! You Need to Install PS2 BIOS [~/RetroPie/BIOS/SCPH-XXXXX.nvm] 1st!" # /dev/shm/runcommand.log is just fine...
	fi
        if [[ "$1" == *"uLaunchELF"* ]] && [[ $(cat /home/pi/.config/pcsx2/inis/PCSX2.ini | grep -q 'EnableFastBoot = false' ; echo $?) == '1' ]]; then sed -i 's+EnableFastBoot\ =.*+EnableFastBoot\ =\ false+g' /home/pi/.config/pcsx2/inis/PCSX2.ini; fi
        if [[ ! "$1" == *"uLaunchELF"* ]] && [[ $(cat /home/pi/.config/pcsx2/inis/PCSX2.ini | grep -q 'EnableFastBoot = true' ; echo $?) == '1' ]]; then sed -i 's+EnableFastBoot\ =.*+EnableFastBoot\ =\ true+g' /home/pi/.config/pcsx2/inis/PCSX2.ini; fi
        $app_dir/$app_img -bigpicture -fullscreen "$@"
fi
popd

# Kill qjoypad
pkill -15 qjoypad > /dev/null 2>&1; rm /tmp/qjoypad.pid > /dev/null 2>&1
exit 0
