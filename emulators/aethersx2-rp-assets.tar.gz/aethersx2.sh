#!/bin/bash

app_img=AetherSX2-v1.5-3606.AppImage
app_dir=/opt/retropie/emulators/aethersx2
pushd $app_dir

# Start Emulator
if [[ "$1" == '' ]] || [[ "$1" == *"+Start AetherSX2"* ]]; then
	VC4_DEBUG=always_sync $app_dir/$app_img -bigpicture -fullscreen
elif [[ "$1" == *"--editor"* ]]; then
	VC4_DEBUG=always_sync $app_dir/$app_img -fullscreen
else
	if [ "$(ls ~/RetroPie/BIOS/SCPH*)" == '' ] && [ "$(ls ~/RetroPie/BIOS/scph*)" == '' ] && [ "$(ls ~/RetroPie/BIOS/ps2*)" == '' ]; then #DisplayMissingBIOS
		#sudo fbi -T 2 -a -noverbose $app_dir/PS2BIOSRequired.jpg > /dev/null 2>&1; sleep 7; sudo kill $(pgrep fbi) > /dev/null 2>&1; exit 0
		echo "***N0TICE***  PS2 BIOS NOT FOUND! You Need to Install PS2 BIOS [~/RetroPie/BIOS/SCPH-XXXXX.nvm] 1st!" # /dev/shm/runcommand.log is just fine...
	fi
        if [[ "$1" == *"uLaunchELF"* ]] && [[ $(cat /home/pi/.config/aethersx2/inis/PCSX2.ini | grep -q 'EnableFastBoot = false' ; echo $?) == '1' ]]; then sed -i 's+EnableFastBoot\ =.*+EnableFastBoot\ =\ false+g' /home/pi/.config/aethersx2/inis/PCSX2.ini; fi
        if [[ ! "$1" == *"uLaunchELF"* ]] && [[ $(cat /home/pi/.config/aethersx2/inis/PCSX2.ini | grep -q 'EnableFastBoot = true' ; echo $?) == '1' ]]; then sed -i 's+EnableFastBoot\ =.*+EnableFastBoot\ =\ true+g' /home/pi/.config/aethersx2/inis/PCSX2.ini; fi
        VC4_DEBUG=always_sync $app_dir/$app_img -bigpicture -fullscreen "$@"
fi
popd
